package com.p2pmyself.app;

import android.app.Activity;
import android.content.Context;
import android.widget.Toast;
import fi.iki.elonen.NanoHTTPD;
import java.io.IOException;
import java.util.Map;

public class MyServer extends NanoHTTPD {
    private boolean isRunning = false;

    public MyServer() {
        super(5000);
    }

    public void startServer() {
        if (!isRunning) {
            try {
                start(NanoHTTPD.SOCKET_READ_TIMEOUT, false);
                isRunning = true;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void stopServer() {
        if (isRunning) {
            stop();
            isRunning = false;
        }
    }

    @Override
    public Response serve(IHTTPSession session) {
        return newFixedLengthResponse("");
        } 
    
}
