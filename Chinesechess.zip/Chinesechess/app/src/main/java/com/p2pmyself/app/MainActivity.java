//该项目是一个中国象棋对弈项目
//使用 http客户端和服务端同时建立在手机上的方式
//实现在同一局域网内两台手机通过ip实时通信
//通信的格式为
//order:指令(开始比赛start)(移动棋子move)(吃子eat)
//data:数据(start对应为空)(move对应移动棋子的id和移动后的xy坐标)(eat对应被吃的棋子的id)
package com.p2pmyself.app;

import android.app.*;

import android.os.*;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.graphics.drawable.*;
import android.widget.*;
import android.view.*;
import java.util.*;
import java.io.*;
import android.util.*;

public class MainActivity extends Activity
{
	private ui ui;
	private ImageView h;
	private volleytool v;
    private EditText e;
	private EditText e2;
	private MyServer myServer;
	private FrameLayout frameLayout;
	@Override
    protected void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        // 获取FrameLayout和ImageView
        frameLayout = findViewById(R.id.container);
		h = findViewById(R.id.h);
		e = findViewById(R.id.editText);
		e2 = findViewById(R.id.color);
		v = new volleytool(this);
        ui = new ui(this, frameLayout, h,e, e2,v);
        myServer = new MyServer() {
            @Override
            public Response serve(IHTTPSession session)
			{
                Map<String, String> parms = session.getParms(); 
                final String order = parms.get("order");
                final String data=parms.get("data");
                runOnUIThread(new Runnable() {
						@Override
						public void run()
						{   if (order.equals("start")){ui.initchess(frameLayout);}
							if (order.equals("move")) {ui.movechess(Integer.parseInt(data.split("。")[0]),new int[]{Integer.parseInt(data.split("。")[1]),Integer.parseInt(data.split("。")[2])});ui.initchess(frameLayout);}
							if(order.equals("eat")){ui.deletechess(Integer.parseInt(data));ui.initchess(frameLayout);}
						}
					});
                return newFixedLengthResponse("");
			}

        };
        myServer.startServer();
    }
    public void start(View view)
	{    
        ui.initchess(frameLayout);
        v.sendget("http://"+e.getText().toString()+":5000?"+ui.makegetorder("order", "start", "data", ""));
    }
	//---------------------
	public void runOnUIThread(Runnable runnable)
	{runOnUiThread(runnable);}
	//活动销毁时,关闭服务器-------------
    @Override protected void onDestroy()
	{super.onDestroy();if (myServer != null)
		{myServer.stopServer();}}
}