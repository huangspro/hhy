package com.p2pmyself.app;

import android.widget.*;
import android.graphics.drawable.*;
import android.os.*;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.graphics.drawable.*;
import android.widget.*;
import android.view.*;
import android.content.*;
public class ui
{	//红方旗子与蓝方棋子
	public Object[][] redchess = { {0, 9, "车","r",1}, {1, 9, "马","r",2}, {2, 9, "象","r",3}, {3, 9, "仕","r",4}, {4, 9, "帅","r",5}, {5, 9, "仕","r",6}, {6, 9, "象","r",7}, {7, 9, "马","r",8}, {8, 9, "车","r",9}, {1, 7, "炮","r",10}, {7, 7, "炮","r",11}, {0, 6, "兵","r",12}, {2, 6, "兵","r",13}, {4, 6, "兵","r",14}, {6, 6, "兵","r",15}, {8, 6, "兵","r",16} };
	public Object[][] bluechess = { {0, 0, "车","b",17}, {1, 0, "马","b",18}, {2, 0, "象","b",19}, {3, 0, "仕","b",20}, {4, 0, "帅","b",21}, {5, 0, "仕","b",22}, {6, 0, "象","b",23}, {7, 0, "马","b",24}, {8, 0, "车","b",25}, {1, 2, "炮","b",26}, {7, 2, "炮","b",27}, {0, 3, "兵","b",28}, {2, 3, "兵","b",29}, {4, 3, "兵","b",30}, {6, 3, "兵","b",31}, {8, 3, "兵","b",32} };
	public int tem=1;//点击次数
	public int chess;//当前被点击到的棋子的id
	private Context context;
	private FrameLayout f;//帧布局
	private ImageView h;//棋盘
    private volleytool v;//通信工具类
    private EditText e0,e1;//输入框分别为url和颜色
    public ui(final Context context, FrameLayout frameLayout, ImageView ImageView,EditText ee0,EditText ee1,volleytool volley)
	{
		this.context = context;
		f = frameLayout;h = ImageView;v=volley;
        e0=ee0;e1=ee1;
        //为图片设置一个点击监听事件
		h.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View view, MotionEvent event)
				{
					if (event.getAction() == MotionEvent.ACTION_DOWN)
					{
						int x = (int) event.getX();
						int y = (int) event.getY();
						for (int i=1;i <= 8;i++)
						{
							for (int ii=1;ii <= 9;ii++)
							{
								if ((Math.sqrt(Math.pow((x - (i * 960 / 8)), 2) + Math.pow((y - (ii * 1620 / 9)), 2)) <= 55) && tem==2)
								{ //判断用户点击在了哪个格点上
									movechess(chess ,new int[]{i,ii});
									initchess(f);
                                    v.sendget("http://"+e0.getText().toString()+":5000?"+makegetorder("order","move","data",chess+"。"+i+"。"+ii));
                                    tem=1;chess=1000;
								}else{}
							}
						}
						return true;
					}
					return false;
				}
			});
	}
	//设置按钮，每一个棋子就是一个按钮
	public void makebutton(FrameLayout frameLayout, Object[][] buttonlist)//用于构造按钮,即象棋,如输入[5,0,"将"]
	{	
		for (Object[] b:buttonlist)
		{
			if (b[4] != 0)
			{
				Button button = new Button(context);
				button.setId(b[4]);
				button.setText(b[2].toString());
				GradientDrawable shape = new GradientDrawable();
				shape.setShape(GradientDrawable.OVAL);
				if (b[3].toString() == "r")
				{shape.setColor(0xFFC85050);}
				if (b[3].toString() == "b")
				{shape.setColor(0xFF80C0FF);}
				shape.setStroke(5, 0xFF000000);
				button.setBackground(shape);
				button.setGravity(Gravity.CENTER);
				// 设置Button的LayoutParams来确定其位置
				FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
					FrameLayout.LayoutParams.WRAP_CONTENT,
					FrameLayout.LayoutParams.WRAP_CONTENT
				);
				params.width = 110;params.height = 110;
				params.leftMargin = (int)((Integer)b[0] * 960 / 8 - 105 / 2);//图片的固有大小,105按钮的固有大小
				params.topMargin = (int)((Integer)b[1] * 1620 / 9 - 105 / 2);//图片的固有大小,105按钮的固有大小
				//按钮点击事件
				button.setOnClickListener(new View.OnClickListener() {

						@Override
						public void onClick(View v)
						{
							buttonclick(v.getId());
						}
					});
				// 将Button添加到FrameLayout
				frameLayout.addView(button, params);  
    		}
			else
			{}
		}
	}
	//移动棋子函数
	public void movechess(int id, int position[])
	{
		for (Object[] i:redchess)
		{
			if ((Integer)i[4] == id)
			{i[0] = position[0];i[1] = position[1];}
		}
		for (Object[] i:bluechess)
		{
			if ((Integer)i[4] == id)
			{i[0] = position[0];i[1] = position[1];}
		}
        
        }
	//删除棋子函数
	public void deletechess(int id)
	{
		for (Object[] i:redchess)
		{if ((Integer)i[4] == id)
			{i[0] = 0;i[1] = 0;i[2] = 0;i[3] = 0;i[4] = 0;}}
		for (Object[] i:bluechess)
		{if ((Integer)i[4] == id)
			{i[0] = 0;i[1] = 0;i[2] = 0;i[3] = 0;i[4] = 0;}}
        
        }
	//初始化棋盘
	public void initchess(FrameLayout frameLayout)
	{   int childCount = f.getChildCount();//清除掉所有的已有的棋子
		for (int i = childCount - 1; i >= 0; i--)
		{View view = f.getChildAt(i);if (view instanceof Button)
			{f.removeViewAt(i);}}
		makebutton(frameLayout, redchess);//设置红方棋子
		makebutton(frameLayout, bluechess);//设置蓝方旗子
	}
	//按钮点击事件
	private void buttonclick(int id)
	{   String color=e1.getText().toString();
        if (((id <= 16 && color.equals("red")) || (id > 16 && color .equals("blue"))) && (tem == 1))
		{//第一次点击点击到己方棋子
			chess = id;tem = 2;//储存第1次被点击到的棋子，调整到第2次
		}
		else if (((id <= 16 && color.equals("blue")) || (id > 16 && color.equals("red"))) && (tem == 1))
		{}//第一次点点击到对方棋子,不处理
		else if (tem == 2 && ((id <= 16 && color.equals("blue")) || (id > 16 && color.equals("red"))))
		{//第2次点击到敌方棋子执行吃子
		    //判断被吃的象棋的id
			int x=0;int y=0;
			for (Object[] i:redchess)
			{if ((Integer)i[4] == id)
				{x = i[0];y = i[1];}}
			for (Object[] i:bluechess)
			{if ((Integer)i[4] == id)
				{x = i[0];y = i[1];}}
			deletechess(id);//删除被吃的象棋
		 	movechess(chess, new int[]{x,y});//移动象棋
			v.sendget("http://"+e0.getText().toString()+":5000?"+makegetorder("order","eat","data",id+""));
	        v.sendget("http://"+e0.getText().toString()+":5000?"+makegetorder("order","move","data",chess+"。"+x+"。"+y));
			chess = 1000;
			tem = 1;//记得重置
            initchess(f);
		}
	}
  public String makegetorder(String... params)
	{//该函数用于构造get请求参数,输入a,b,c,d,输出"a=b&c=d"
		StringBuilder formatted = new StringBuilder();
		for (int i = 0; i < params.length; i += 2){if (i > 0){formatted.append("&");}formatted.append(params[i]).append("=").append(params[i + 1]);}
        return formatted.toString();
        }
}