//绘图函数=======================
function showvideo(videoid) {//获取手机摄像头的视频流，并显示在video标签上
    navigator.mediaDevices.getUserMedia({
            video:{facingMode: "environment" } 
        })
        .then(function(stream) {
            // 将媒体流绑定到视频标签
            var video = document.getElementById(videoid);
            video.srcObject = stream;
            video.play();
        })
}

function getcolor(canvasid,x, y) {//该函数获取canvas上某一点的rgb颜色
var canvas =document.getElementById(canvasid);  
var ctx = canvas.getContext('2d');  
var imageData = ctx.getImageData(x, y, 1, 1);
var data = imageData.data;
var r = data[0];
var g = data[1];
var b = data[2];
var color=[r,g,b];
return color;
}

function paintline(canvasid,startX,startY,endX,endY)//该函数在canvas标签中画直线,id为该canvas标签的id
{
    var canvas = document.getElementById(canvasid);  
    var ctx = canvas.getContext('2d');  
    ctx.beginPath();
    ctx.moveTo(startX, startY);  
    ctx.lineTo(endX, endY);
    ctx.strokeStyle = 'black';  
    ctx.lineWidth = 1;  
    ctx.lineJoin = 'miter';  
    ctx.lineCap = 'round';  
    ctx.stroke();  
}


function drawcircle(canvasid,x,y,r,color){
var c = document.getElementById(canvasid);
var ctx = c.getContext("2d");
ctx.strokeStyle = "rgb("+color[0]+","+color[1]+","+color[2]+")";
ctx.lineWidth=10;
ctx.beginPath();
ctx.arc(x,y,r,0,2*Math.PI);
ctx.stroke();
}

function spark(id){
var ok=0;
var i=setInterval(function(){
if(Number.isInteger(ok/2)==true && ok<=7)
    {
    document.getElementById(id).style.border="1px solid red";
    }
if(Number.isInteger(ok/2)==false && ok<=7)
    {
    document.getElementById(id).style.border="1px solid white";
    }
if(ok>7)
    {
    clearInterval(i);
    document.getElementById(id).style.border="1px solid black";}
ok++;
},50);
}
//takepH页面主函数========================
function drawVideoFrame() {
            //把video标签上的视频绘制到canvas标签上
            if (video.paused || video.ended) return;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            //绘制十字线
            paintline("2", canvas.width / 2, 0, canvas.width / 2, canvas.height);
            paintline("2", 0, canvas.height / 2, canvas.width, canvas.height / 2);
            //获取某点的颜色
            drawcircle("2", canvas.width / 2, canvas.height / 2, 30, getcolor("2", (canvas.width / 2)-2, (canvas.height / 2)-2));//注意不能直接取画布中心的颜色，因为画布中心是两条十字线的交叉点，是黑色的
            
            requestAnimationFrame(drawVideoFrame);
        }
//事件函数============================
function save(){//该函数用于将用户已经选好的pH值和颜色值打包成一个txt文件，并下载到用户的设备中,以便于下一次直接使用
const fileContent = colorarray.join(',') + '\n---\n' + pharray.join('\n');
const blob = new Blob([fileContent], { type: 'text/plain;charset=utf-8' });
const url = URL.createObjectURL(blob);
const downloadLink = document.createElement('a');
downloadLink.href = url;
downloadLink.download = 'phdata.txt';
document.body.appendChild(downloadLink);
downloadLink.click();
document.body.removeChild(downloadLink);
URL.revokeObjectURL(url);
}

function openph(){//该函数获取用户上传的txt文件，并从中把pH数据和颜色数据提取出来
  // 获取文件输入元素
  const fileInput = document.getElementById('open');
  // 检查是否有文件被选中
  if (fileInput.files && fileInput.files[0]) {
    // 创建一个FileReader对象
    const reader = new FileReader();
    // 读取文件内容
    reader.onload = function(event) {
      // 确保这部分代码在文件读取完成后执行
      const content = event.target.result;
      const splitContent = content.split('\n---\n');
      const array1 = cut(splitContent[0].split(','),3);
      const array2 = splitContent[1].split('\n');
      // 将数组数据存储在 sessionStorage 中
      sessionStorage.setItem('color', JSON.stringify(array1));
      sessionStorage.setItem('ph', JSON.stringify(array2));
      // 导航到 "infer.html" 页面
      window.location.href = "infer.html";
    };
    // 开始读取文件，确保这一行在 if 语句内部
    reader.readAsText(fileInput.files[0]);
  }
  else
  {
  spark("open");
  }

}

function cut(arr, chunkSize) {//将一维数组中的元素几个几个一组，分成一个二维数组
  return arr.reduce((accumulator, currentValue, currentIndex) => {
    const chunkIndex = Math.floor(currentIndex / chunkSize);
    if (!accumulator[chunkIndex]) {
      accumulator[chunkIndex] = [];
    }
    accumulator[chunkIndex].push(currentValue);
    return accumulator;
  }, []);
}

function getcolordistance(a,b){//该函数计算两个rgb颜色的相似度
var r1=a[0];var r2=b[0];
var g1=a[1];var g2=b[1];
var b1=a[2];var b2=b[2];
var distance=Math.sqrt((r1-r2)**2+(g1-g2)**2+(b1-b2)**2);
return distance;
}

function remove(){
colorarray.pop();
pharray.pop();
alert("已移除");
}