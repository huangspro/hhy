function paintline(id,startX,startY,endX,endY)//该函数在canvas标签中画直线,id为该canvas标签的id
{
    var canvas = $("#"+id)[0];  
    var ctx = canvas.getContext('2d');  
    ctx.beginPath();
    
    ctx.moveTo(startX, startY);  
    ctx.lineTo(endX, endY);
    ctx.strokeStyle = 'black';  
    ctx.lineWidth = 5;  
    ctx.lineJoin = 'miter';  
    ctx.lineCap = 'round';  
    ctx.stroke();  
}

function drawsquare(id,x,y,width,height,color){
var canvas = document.getElementById(id);
var ctx = canvas.getContext('2d');
ctx.fillStyle =color;
ctx.strokeStyle = 'black';
ctx.lineWidth = 5;
ctx.beginPath();
ctx.fillRect(x,y,width,height);
ctx.fill();
ctx.closePath();
}



function infer(x,y,squarex,squarey,width,height){
if(x+20>squarex && x<squarex+width && y+40>squarey && y<squarey+height)
{
return true;
}
else
{
return false;
}
}

function jump1(){
sy1=-2;
}
function rightjump1(){
sx1=2;
}

function leftjump1(){
sx1=-2;
}

function leftshoot1(){
a1="1";
n1=x1;m1=y1;
}
function rightshoot1(){
a1="2";
n1=x1;m1=y1;
}


function jump2(){
sy2=-2;
}
function rightjump2(){
sx2=2;
}

function leftjump2(){
sx2=-2;
}

function leftshoot2(){
a2="1";
n2=x2;m2=y2;
}
function rightshoot2(){
a2="2";
n2=x2;m2=y2;
}

function drawpicture1(x,y) {
    var canvas = document.getElementById('m');
    var ctx = canvas.getContext('2d');
    var img = new Image();
    img.src = '1.jpg'; // 替换为你的图片路径
    ctx.drawImage(img, x, y, 20,40);
    }
    
function drawpicture2(x,y) {
    var canvas = document.getElementById('m');
    var ctx = canvas.getContext('2d');
    var img = new Image();
    img.src = '2.jpg'; // 替换为你的图片路径
    ctx.drawImage(img, x, y, 20,40);
    }

function inferpoint(x,y,squarex,squarey,width,height){
if(x>squarex && x<squarex+width && y>squarey && y<squarey+height)
{
return true;
}
else
{
return false;
}
}