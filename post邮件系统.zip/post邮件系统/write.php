<?php
$u=$_POST['usersname'];
$p=$_POST['password'];
$uu=fopen('u.txt',"a");//打开u.txt文件该文件用于存储用户的用户名
$pp=fopen('p.txt',"a");//打开p.txt文件该文件用于存储用户的密码
fwrite($uu,$u."\n");//写入用户名
fwrite($pp,$p."\n");//写入密码
fclose($uu);//关闭文件，防止该文件的句柄被占用影响其他操作
fclose($pp);
$file=fopen($u.".txt","a");//创建个人用户界面,其中用到了html滑动条,具体技术见html滑动条的使用，网址"https://m.php.cn/faq/539288.html"
$txtpermanent='<meta charset="UTF-8"><style>.scrollable{width: 350px;height:300px;overflow-y: auto;border: 1px solid #ccc;padding: 10px;}div{border-radius: 10px;}body{background-image:url("back1.jpg");background-size:cover;}</style><script src="https://code.jquery.com/jquery-3.6.0.min.js"></script><script>$(document).ready(function(){$(".scrollable").css("overflow-y", "auto");});</script><p>'.$u.'的邮件</p>'.'<a href="'.$u.'send.html">发消息给其他用户</a>';
fwrite($file,$txtpermanent);
$newname=rename($u.".txt", $u.".html");
fclose($file);

$send=fopen($u."send.txt","a");//创建个人消息发送文件,用户可在这个文件中进行数据发送
$t1='<meta charset="UTF-8"><style>textarea {border-radius: 20px;}input {border-radius: 10px;}button {background-color:lightgreen;border-radius: 50px;}body{background-image:url("back.jpg");background-size:cover;}</style>';
$t2='<body><p>在这里发送你的邮件</p><p>请输入要发送的目标用户名</p><input id="tousersname" type="text"></input><p id="2" style="color:red"></p><p>请输入要发送的内容</p><textarea style="height:100px;width:300px;" id="content" rows="100" cols="100" type="text"></textarea><p id="3" style="color:red"></p><br><button style="background-color:lightgreen" type="button" id="submit">发送</button><p style="color:green;" id="fun"></p>  <script src="https://cdn.staticfile.org/jquery/1.10.2/jquery.min.js"></script><script>$("#submit").click(function(){var u="'.$u.'";var to=document.getElementById("tousersname").value;var con=document.getElementById("content").value;if(u!="" && to!="" && con!=""){$.ajax({url: "send.php",method: "POST",data: {"usersname":u,"content":con,"tousersname":to},success: function() {$("#fun").html("发送成功");}});}if(u==""){$("#1").html("您的用户名不可为空");}if(to==""){$("#2").html("用户名不可为空");}if(con==""){$("#3").html("不可以发送空信息");}});</script>';
//上面的文本文件太长,分开t1和t2两个变量存储
fwrite($send,$t1.$t2);
$newname=rename($u."send.txt", $u."send.html");//重命名为一个html文件
fclose($send);
?>