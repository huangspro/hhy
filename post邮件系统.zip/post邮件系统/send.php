/*该文件完成消息发送任务,通过接收个人发送界面中的数据,将其写入另一个用户的个人界面
即完成消息发送
*/

<?php
//获取个人发送界面中传来的数据
$u=$_POST['usersname'];
$to=$_POST['tousersname'];
$con=$_POST['content'];

//获取消息发送的时间
$timestamp = time();
$date = date('Y-m-d H:i:s', $timestamp);

//进行消息写入
$rename=rename($to.".html",$to.".txt");//先把个人用户界面转化为txt文件,方便写入
$file=fopen($to.".txt","a");
$txt='<br><div class="scrollable" style="background-color:lightgreen;" >'.$date.'<br>收到从'.$u.'发来的消息：<br>'.$con.'</div><br><br><br>';
fwrite($file,$txt);
fclose($file);
$renam=rename($to.".txt",$to.".html");//消息内容写入完毕后,再把txt文件转化为html文件
?>