/*该文件为登录界面的配套逻辑运算,通过p.txt文件中的用户名,检测p点txt中的密码是否匹配
状态码1:密码匹配,登录成功
状态码2:密码不匹配,登录失败
状态码3:用户名不存在
*/
<?php
//该函数将返回字符串在txt文件中的行数，注意有换行符
function find($p,$i){
$o=0;
$h=file($p);
foreach($h as $f){
if($f==$i."\n"){break;}
$o++;
}
return $o;
}
//---------------------------------
$u=$_POST['usersname'];
$p=$_POST['password'];
if(in_array($u."\n",file("u.txt"))!=true){
echo json_encode(array('status'=>'3'));}

else{
if(file("p.txt")[find("u.txt",$u)]==$p){
    echo json_encode(array('status'=>'1'));}
if(file("p.txt")[find("u.txt",$u)]!=$p){
    echo json_encode(array('status'=>'2'));}
}
?>