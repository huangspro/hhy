package com.httpserver.app;

import fi.iki.elonen.NanoHTTPD;
import org.json.JSONObject;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import android.widget.EditText;
import java.io.IOException;
import java.util.Map;
import fi.iki.elonen.NanoHTTPD;

public class MyServer extends NanoHTTPD { 
private boolean isRunning = false;
public MyServer() {
	super(5000); 
	} 
	public void startServer() {
        if (!isRunning) {
            try {
                start(NanoHTTPD.SOCKET_READ_TIMEOUT, false);
                isRunning = true;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
public void stopServer() {
        if (isRunning) {
            stop();
            isRunning = false;
        }
    }
	@Override 
	public Response serve(IHTTPSession session) { 
	Method method = session.getMethod();
	String msg = "{\"message\": \"llll\"}";
	Map<String, String> parms = session.getParms(); 
	String u=parms.get("username");
	return newFixedLengthResponse(msg); }
	}
