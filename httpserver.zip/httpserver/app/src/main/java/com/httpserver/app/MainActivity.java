package com.httpserver.app;

import android.app.Activity;
import android.content.Context;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import fi.iki.elonen.NanoHTTPD;
import java.io.IOException;
import android.widget.EditText;

public class MainActivity extends Activity {
    Context context = this;
    MyServer myServer; // 声明为成员变量
	
    // 安卓创建事件
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
            myServer = new MyServer(); // 实例化
            myServer.startServer();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 在Activity销毁时停止服务器
        if (myServer != null) {
            myServer.stopServer();
        }
    }
}
