<?php
function getjsonvalue($key,$document)//该函数读取json文件,获取相应的键对应的值
{
$jsonData = file_get_contents($document);
$data = json_decode($jsonData, true);
if (isset($data[$key]))
{
return $data[$key];
}
else
{
return "keynotin";
}
}

function newjson($key,$value,$document)//该函数在指定的json文件中追加新的键值对
{
$newKey =$key ;
$newValue =$value;
$jsonData = file_get_contents($document);
$data = json_decode($jsonData, true);
$data[$newKey] = $newValue;
$jsonData = json_encode($data);
file_put_contents($document, $jsonData);
}

function logincheck($key,$value,$document)//该函数用于检验json文件中，键值对是否匹配
{
$v=getjsonvalue($key,$document);
if($v!=false)
{
if($v==$value)
{
return 1;
}
else
{
return 2;
}
}
else
{
return "keynotin";
}
}

function checkkeyin($key,$document)//该函数判断键是否在json文件中
{
$jsonData = file_get_contents($document);
$data = json_decode($jsonData, true);
if (isset($data[$key]))
{
return "in";
}
else
{
return "notin";
}
}


?>