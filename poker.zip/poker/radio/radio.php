<?php
include "function.php";

$peo=getjsonvalue("peo","radio.json");
$poker=getjsonvalue("poker","radio.json");

echo json_encode(array('peo'=>$peo,'poker'=>$poker));
?>