<?php  
include "function.php";
newjson("peo","4","radio.json");
newjson("poker","","radio.json");

newjson("1","","poker.json");
newjson("2","","poker.json");
newjson("3","","poker.json");
newjson("4","","poker.json");
// 原始数组  
$a=['♥A', '♥2', '♥3', '♥4', '♥5', '♥6', '♥7', '♥8', '♥9', '♥10', '♥J', '♥Q', '♥K', '♠A', '♠2', '♠3', '♠4', '♠5', '♠6', '♠7', '♠8', '♠9', '♠10', '♠J', '♠Q', '♠K', '♣A', '♣2', '♣3', '♣4', '♣5', '♣6', '♣7', '♣8', '♣9', '♣10', '♣J', '♣Q', '♣K', '♦A', '♦2', '♦3', '♦4', '♦5', '♦6', '♦7', '♦8', '♦9', '♦10', '♦J', '♦Q', '♦K']; 
shuffle($a);  
$p1="";
$p2="";
$p3="";
$p4="";
for($i=0;$i<13;$i++)
{
$p1=$p1.$a[$i]." ";
}
for($i=13;$i<26;$i++)
{
$p2=$p2.$a[$i]." ";
}
for($i=26;$i<39;$i++)
{
$p3=$p3.$a[$i]." ";
}
for($i=39;$i<52;$i++)
{
$p4=$p4.$a[$i]." ";
}

newjson("1",$p1,"poker.json");
newjson("2",$p2,"poker.json");
newjson("3",$p3,"poker.json");
newjson("4",$p4,"poker.json");
?>