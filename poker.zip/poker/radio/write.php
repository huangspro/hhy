<?php
include "function.php";

$peo=$_POST["peo"];;
$poker=$_POST["poker"];
newjson("peo",$peo,"radio.json");
newjson("poker",$poker,"radio.json");
?>