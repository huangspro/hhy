<?php
include "function.php";

newjson("1","","poker.json");
newjson("2","","poker.json");
newjson("3","","poker.json");
newjson("4","","poker.json");
newjson("poker","","radio.json");
newjson("peo","4","radio.json");
?>