<?php
include "function.php";

$p1=getjsonvalue("1","poker.json");
$p2=getjsonvalue("2","poker.json");
$p3=getjsonvalue("3","poker.json");
$p4=getjsonvalue("4","poker.json");

echo json_encode(array('1'=>$p1,'2'=>$p2,"3"=>$p3,"4"=>$p4));
?>