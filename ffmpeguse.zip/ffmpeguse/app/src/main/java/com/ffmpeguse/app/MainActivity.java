package com.ffmpeguse.app;

import android.app.*;
import android.os.Bundle;
import com.arthenica.mobileffmpeg.FFmpeg;
import android.widget.Toast;
import android.widget.Button;
import android.widget.EditText;
import android.view.*;
public class MainActivity extends Activity {
    private filehelp f;
	private EditText path;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		path=findViewById(R.id.path);
		f=new filehelp(this);
		f.getpermission(this);
		}
	
    public void startrun(View view) {
		Toast.makeText(this,"开始转换，需要一定时间",Toast.LENGTH_LONG).show();
        String[] command = new String[]{
                "-i","/storage/emulated/0/"+path.getText().toString(),
                "-vn",
                "-ar", "44100",
                "-ac", "2",
                "-ab", "192k",
                "-f", "mp3",
                "/storage/emulated/0/"+path.getText().toString().replace("mp4","mp3")
        };
        if(FFmpeg.execute(command)==0){
			Toast.makeText(this,"已转换",Toast.LENGTH_LONG).show();
		}else{
			Toast.makeText(this,"转换失败",Toast.LENGTH_LONG).show();
		}
    }
}