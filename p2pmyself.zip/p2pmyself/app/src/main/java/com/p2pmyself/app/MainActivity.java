package com.p2pmyself.app;

import android.app.*;
import android.os.*;
import java.util.*;
import android.widget.*;
import android.view.*;

public class MainActivity extends Activity 
{
	private volleytool v;
	private jsonhelp j;
	private MyServer myServer;
	private EditText input;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		v = new volleytool(this);
		j = new jsonhelp();
		input=findViewById(R.id.input);
   		myServer = new MyServer() {
			@Override
			public Response serve(IHTTPSession session)
			{
                Map<String, String> parms = session.getParms();
                final String username = parms.get("m");
                runOnUIThread(new Runnable() {
						@Override
						public void run()
						{
							Toast.makeText(MainActivity.this, "message:" + username, Toast.LENGTH_SHORT).show();
						}
					});
                return newFixedLengthResponse("");
            }
        };
        myServer.startServer();
    }
    public void runOnUIThread(Runnable runnable){runOnUiThread(runnable);}
    @Override protected void onDestroy(){super.onDestroy();if (myServer != null){myServer.stopServer();}}
	public void sendurl(View view){
		v.sendget(input.getText().toString());
	}
}