function paintline(canvasid,startX,startY,endX,endY)//该函数在canvas标签中画直线,id为该canvas标签的id
{
    var canvas = document.getElementById(canvasid);  
    var ctx = canvas.getContext('2d');  
    ctx.beginPath();
    ctx.moveTo(startX, startY);  
    ctx.lineTo(endX, endY);
    ctx.strokeStyle = 'black';  
    ctx.lineWidth = 1;  
    ctx.lineJoin = 'miter';  
    ctx.lineCap = 'round';  
    ctx.stroke();  
}

function paintline_useforfunction(canvasid,startX,startY,endX,endY)//该函数在canvas标签中画直线,id为该canvas标签的id
{
    var canvas = document.getElementById(canvasid);  
    var ctx = canvas.getContext('2d');  
    ctx.beginPath();
    ctx.moveTo(startX, startY);  
    ctx.lineTo(endX, endY);
    ctx.strokeStyle = 'blue';  
    ctx.lineWidth = 1.2;  
    ctx.lineJoin = 'miter';  
    ctx.lineCap = 'round';  
    ctx.stroke();  
}

function drawTextOnCanvas(canvasId, x, y, text) {
    var canvas = document.getElementById(canvasId);
    var ctx = canvas.getContext('2d');
    ctx.font = '15px Arial';
    ctx.fillStyle = 'black';
    ctx.fillText(text, x, y);
}

function drawCircleOnCanvas(canvasId, x, y, radius, color) {
    var canvas = document.getElementById(canvasId);
    var ctx = canvas.getContext('2d');
    ctx.save();
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
}

function drawfunction(canvasid,string,step,x,y){//绘制函数图像与散点
var canvas=document.getElementById(canvasid);
var xmax = Math.max.apply(null, x);
var xmin = Math.min.apply(null, x);
var ymax = Math.max.apply(null, y);
var ymin = Math.min.apply(null, y);
var xunitlength=(canvas.width*4/5)/(xmax*1.1);//X轴单位长度
var yunitlength=(canvas.height*4/5)/(ymax*1.1);//Y轴单位长度
document.getElementById(canvasid);
paintline(canvasid,0,canvas.height*4/5,canvas.width,canvas.height*4/5);
paintline(canvasid,canvas.width/5,0,canvas.width/5,canvas.height);
drawTextOnCanvas(canvasid,canvas.width/5,canvas.height*2/2.5,"0");
drawTextOnCanvas(canvasid,canvas.width-15,canvas.height*2/2.5,xmax);
drawTextOnCanvas(canvasid,canvas.width/5,15,ymax);

for(var i=0;i<x.length;i++)
{
drawCircleOnCanvas(canvasid,canvas.width/5+x[i]*xunitlength,canvas.height*4/5-y[i]*yunitlength,3,"red");
}
var i=xmin;
while(i<=xmax)
{
paintline_useforfunction(canvasid,canvas.width/5+i*xunitlength,canvas.height*4/5-calculate(string,i)*yunitlength,canvas.width/5+(i+step)*xunitlength,canvas.height*4/5-calculate(string,i+step)*yunitlength);
i+=step;
}
}