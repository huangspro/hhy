function leastSquares(x, y) {
    // 1. 计算 x 和 y 的平均值
    let sumX = 0;
    let sumY = 0;
    for (let i = 0; i < x.length; i++) {
        sumX += x[i];
        sumY += y[i];
    }
    let meanX = sumX / x.length;
    let meanY = sumY / y.length;

    // 2. 计算斜率
    let numerator = 0;
    let denominator = 0;
    for (let i = 0; i < x.length; i++) {
        numerator += (x[i] - meanX) * (y[i] - meanY);
        denominator += Math.pow(x[i] - meanX, 2);
    }
    let slope = numerator / denominator;

    // 3. 计算截距
    let intercept = meanY - slope * meanX;

    // 4. 计算决定系数 R²
    let SSR = 0; // Sum of Squared Residuals
    let SST = 0; // Total Sum of Squares
    for (let i = 0; i < x.length; i++) {
        let predictedY = slope * x[i] + intercept;
        SSR += Math.pow(y[i] - predictedY, 2);
        SST += Math.pow(y[i] - meanY, 2);
    }
    let rSquared = 1 - (SSR / SST);

    // 返回结果对象
    return [slope, intercept, rSquared];
}



function calculate(string, x) { //把x的值代入关于x的代数式中并计算结果
    let expression = string;
    let result = eval(expression.replace('x', x));
    return result;
}



function polynomialfitting(x, y, n) //n为高阶多项式拟合的阶数,即多项式的项数，包含常数项
{
    function sum1(a) { //对一个数组进行求和
        return eval(a.join("+"));
    }

    function sum2(a, x, y) { //该函数专门用于高阶多项式分解中数组的求和，a为x数据的指数
        var sumresult = 0;
        for (let i = 0; i < x.length; i++) {
            sumresult += (x[i] ** a) * (y[i]);
        }
        return 2 * sumresult;
    }
    //以下代码将完成方程组项系数的二维数组的写入================        
    var v = []; //方程组的二维数组，系数矩阵
    var tem = []; //临时变量，用于存储
    var tem2 = 0; //临时变量2，用于调整指数
    while (tem2 <= n - 1) {
        for (var ii = 2 * (n - 1) - tem2; ii >= n - 1 - tem2; ii--) {
            tem.push(2 * sum1(x.map(i => i ** ii)));
        }
        tem2++;
        v.push(tem);
        var tem = [];
    }
    //得到的数组v即为项系数数组=====================
    //以下代码将完成方程组常数项数组的编写=============
    var c = []; //方程组的常数项数组，一维数组
    for (var ii = n - 1; ii >= 0; ii--) {
        c.push(sum2(ii, x, y));
    }
    //得到的数组c即为常数项数组=================
    const solution = math.lusolve(v, c);
    var result = [];
    for (var i = 0; i < solution.length; i++) {
        result.push(`${solution[i][0]}*x**${n-1-i}`);
    }
    return result.join("+");
}


function make1(string) {//处理对数字符串,更美观
    function extractVariables(str) {
        const regex = /Math.log\(([a-zA-Z0-9.]+)\)\/Math.log\(([a-zA-Z0-9.]+)\)/;
        const matches = str.match(regex);

        if (matches && matches.length > 2) {
            return {
                a: matches[1],
                b: matches[2]
            };
        } else {
            return null; // 没有匹配到，或者格式不正确
        }
    }
    var t = extractVariables(string);
    let latex = "log<sub>" + t.b + "</sub>" + t.a;
    return latex;
}

function make2(a)//处理多项式字符串,更美观
{
var b=a.split("**").join("<sup>").split("+");
return b.join("</sup>+").split("*").join("")+"</sup>";
}