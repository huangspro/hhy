function get(x,y)
{
document.getElementById("result").innerHTML="计算中...";
//幂函数================
if(x!="" && y!="" && x.split(",").length==y.split(",").length && document.getElementById("functiontype").value=="1")
    {
    x=x.split(",").map(s=>Number(s));
    y=y.split(",").map(s=>Number(s));
    var list=[];//拟合结果的数组,为二位数组，每一个元素包含 斜率,截距,决定系数,对应的函数模板
    var tem=[];//临时数组,用于存储决定系数

    for(var ii=-5;ii<=10;ii+=0.01)
        {//遍历所有函数模板
        var i=`x**${ii}`;
        var xi=x.map(s=>calculate(i,s));//使用函数模板得到新的解释变量
        list.push(leastSquares(xi,y));//利用最小二乘得到新的解释变量与y之间的关系
        list[list.length-1].push(i);//在每一个结果后面加上对应的函数模板
        }
    for(var i of list)
        {
        tem.push(i[2]);//将每一个运算结果的决定系数存储在临时数组中
        }
    var max=tem.indexOf(Math.max.apply(null,tem));//获取决定系数的最大值对应的索引
    drawfunction("function",list[max][0].toFixed(5)+"*"+list[max][3]+"+("+list[max][1].toFixed(5)+")",0.001,x,y);//将结果中的新的解释变量替换为原来的解释变量所对应的函数模板,并绘图
    document.getElementById("result").innerHTML=`${list[max][0].toFixed(5)}${list[max][3].replace("**","<sup>")}</sup>+(${list[max][1].toFixed(5)})`;//输出拟合结果
    functionpredict=list[max][0].toFixed(5)+"*"+list[max][3]+"+("+list[max][1].toFixed(5)+")";
    }
//对数函数================
if(x!="" && y!="" && x.split(",").length==y.split(",").length && document.getElementById("functiontype").value=="2")
    {
    x=x.split(",").map(s=>Number(s));
    y=y.split(",").map(s=>Number(s));
    var list=[];//拟合结果的数组,为二位数组，每一个元素包含 斜率,截距,决定系数,对应的函数模板
    var tem=[];//临时数组,用于存储决定系数

    for(var ii=0.01;ii<=5;ii+=0.01){
                var i=`Math.log(x)/Math.log(${ii})`;
                var xi=x.map(s=>calculate(i,s));//使用函数模板得到新的解释变量
                list.push(leastSquares(xi,y));//利用最小二乘得到新的解释变量与y之间的关系
                list[list.length-1].push(i);//在每一个结果后面加上对应的函数模板
                }
    for(var i of list)
        {
        tem.push(i[2]);//将每一个运算结果的决定系数存储在临时数组中
        }
    var max=tem.indexOf(Math.max.apply(null,tem));//获取决定系数的最大值对应的索引
    drawfunction("function",list[max][0].toFixed(5)+"*"+list[max][3]+"+("+list[max][1].toFixed(5)+")",0.001,x,y);//将结果中的新的解释变量替换为原来的解释变量所对应的函数模板,并绘图
    var t=make1(list[max][3]);
    document.getElementById("result").innerHTML=`${list[max][0].toFixed(5)}${t}+(${list[max][1].toFixed(5)})`;//输出拟合结果
    functionpredict=list[max][0].toFixed(5)+"*"+list[max][3]+"+("+list[max][1].toFixed(5)+")";
    }
//高阶多项式拟合=============
if(x!="" && y!="" && x.split(",").length==y.split(",").length && document.getElementById("functiontype").value=="5")
    {
    x=x.split(",").map(s=>Number(s));
    y=y.split(",").map(s=>Number(s));
    drawfunction("function",polynomialfitting(x,y,document.getElementById("order").value),0.001,x,y);//将结果中的新的解释变量替换为原来的解释变量所对应的函数模板,并绘图
    document.getElementById("result").innerHTML=make2(polynomialfitting(x,y,document.getElementById("order").value));//输出拟合结果
    functionpredict=polynomialfitting(x,y,document.getElementById("order").value);
    }
//错误处理================
if(x=="" || y=="" || x.split(",").length!=y.split(",").length){alert("请检查输入格式");}
}