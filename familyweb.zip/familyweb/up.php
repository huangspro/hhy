<?php
$targetDirectory = "upload/";
$targetFile = $targetDirectory . basename($_FILES["file"]["name"]);
$imageFileType = strtolower(pathinfo($targetFile,PATHINFO_EXTENSION));
if (file_exists($targetFile))
{
    echo "文件已经存在";
}
else
{
    move_uploaded_file($_FILES["file"]["tmp_name"], $targetFile);
}
?>