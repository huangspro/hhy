function uploadmulfile(uploadurl, uploadbuttonid, uploadinputid, progressid) {
    document.getElementById(uploadbuttonid).addEventListener('click', function(e) {
        e.preventDefault();

        var fileInput = document.getElementById(uploadinputid);
        var files = fileInput.files;
        var progressDiv = document.getElementById(progressid);
        var totalFiles = files.length;
        var currentFile = 0;
        progressDiv.textContent = '';

        // 上传文件函数
        function uploadFile(file) {
            var xhr = new XMLHttpRequest();
            xhr.upload.onprogress = function(e) {
                if (e.lengthComputable) {
                    var percentComplete = (e.loaded / e.total) * 100;
                    progressDiv.textContent = '文件 ' + (currentFile + 1) + ': ' + percentComplete.toFixed(2) + '% 上传中\n';
                }
            };

            xhr.onload = function() {
                currentFile++;
                if (currentFile < totalFiles) {
                    uploadFile(files[currentFile]);
                } else {
                    alert("上传完成");
                    // 所有文件上传完成后，再调用getpath函数
                    getpath("upload/"); // 注意：这里假设`now`是一个在外部定义的变量
                    progressDiv.textContent = '';
                }
            };

            var formData = new FormData();
            formData.append('file', file);
            // 确保uploadpath是一个有效的字符串
            xhr.open('POST', uploadurl, true);
            xhr.send(formData);
        }

        if (files.length > 0) {
            uploadFile(files[currentFile]);
        } else {
            alert('请选择文件');
        }

        });
}
    

function getpath(path) {
    $.ajax({
    url: "scan.php",
    method: "POST",
    data: {'path':path},
    success: function(data) {
    $(".files").remove();
    var files = JSON.parse(data)["files"];
    creatfiles(files);
    }
    });
    }


function creatfiles(a){
var files=$("#files");
for (var i of a){
var file = $('<div class="files"><img class="filesimg"></img><input type="checkbox" class="delete"><img src="resources/download.jpg" class="download"></img>'+i+'</div>');
files.append(file);
if(i.includes(".jpg") || i.includes(".wepg") || i.includes(".png") || i.includes(".jpeg") || i.includes(".JPG") || i.includes(".JPEG") || i.includes(".PNG"))
    {file.children(".filesimg").attr("src","upload/"+i);file.children(".filesimg").click(function(){showpicture("upload/"+i)});}
else{file.children(".filesimg").attr("src","resources/files.jpg");}
file.children(".download").click(function(){
    const downloadLink = document.createElement('a');
    downloadLink.href = `upload/${$(this).parent().text()}`;
    downloadLink.download =`${$(this).parent().text()}`;
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
    });
}
}

function cutpath(a){
let tem = a.substring(0, a.length - 1);
var b=tem.split("/");
b.pop();
return b.join("/")+"/";
}

function showpicture(a){
var p=$(`<img style="position:absolute;top:20vh;height:60vh;width:100vw;" src="${a}">`);
var background=$(`<div style="position:absolute;top:0;left:0;height:100vh;width:100vw;background-color:black;"></div>`)
$("body").append(background);
$("body").append(p);
p.click(function(){p.remove();background.remove();});
background.click(function(){p.remove();background.remove();});
}