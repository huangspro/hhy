<?php

$directory =$_POST["path"];
$files = scandir($directory);
$folders = [];
$fileNames = [];

foreach ($files as $file) {
    if ($file != '.' && $file != '..') {
        if (is_dir($directory . '/' . $file)) {
            $folders[] = $file;
        } else {
            $fileNames[] = $file; 
        }
    }
}

$data = [
    'folders' => $folders,
    'files' => $fileNames
];
$jsonData = json_encode($data);
echo $jsonData;

?>