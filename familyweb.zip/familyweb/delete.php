<?php
$url=$_POST["delete"];
foreach($url as $u)
{
unlink($u);
}
?>