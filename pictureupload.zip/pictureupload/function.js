function cut(str, chunkSize = 15000) {
    const chunks = [];
    for (let i = 0; i < str.length; i += chunkSize) {
        const chunk = str.slice(i, i + chunkSize);
        chunks.push(chunk);
    }
    return chunks;
}

function uploadpicture()
{
const fileInput = document.getElementById('file');
const file = fileInput.files[0];
if (file) {
const reader = new FileReader();
reader.onload = function(event) 
{
  const b = event.target.result;
  const dd = cut(b);
  var i=0;
  function ajax(){
     if(i<dd.length){
     document.getElementById("pro").innerHTML=((i/dd.length)*100).toFixed(3)+"%";
     $.ajax({
     url: "picture.php",
     method: "POST",
     data: { "p": dd[i], "name": file.name },
     success:function(){i++;ajax();}
     });}
     else{$.ajax({
     url: "ok.php",
     method: "POST",
     data: {"name": file.name }});
     get();
     alert('ok');
     document.getElementById("pro").innerHTML="";}
     }
  ajax();
};
reader.readAsDataURL(file);
} 
}

function get(){
document.getElementById("array").innerHTML="";
$.ajax({
    url: "get.php",
    method: "POST",
    success:function(data){
    var d=JSON.parse(data)["array"];
    for(var i of d){
        $("#array").append('<div style="background-color:lightgreen;width:100vw"><img height="40" width="40" src="picture/'+i+'"></img><button id="'+i+'" onclick="deletei(this)">删除</button><button id="'+i+'" onclick="d(this)">下载</button><button onclick="show(this)" id="'+i+'">预览</button>'+i+'</div>');
        }
    }
});
}

function deletei(a){
var c=confirm('确认删除'+a.id+" ？");
if(c==true){
$.ajax({
     url: "delete.php",
     method: "POST",
     data: {"url":a.id},
     success:function(){alert("删除成功");get();}
     });}
}

function d(a){
simulateDownload("picture/"+a.id);
}

function simulateDownload(fileUrl, fileName) {
    // 创建一个新的a标签
    var elem = window.document.createElement('a');
    elem.href = fileUrl;
    elem.download = fileName || 'unknown'; // 设置下载文件的名称，如果未提供则使用 'unknown'

    // 为了确保下载能够触发，需要将元素添加到DOM中
    document.body.appendChild(elem);

    // 触发点击事件
    elem.click();

    // 然后移除这个元素
    document.body.removeChild(elem);
}

function show(a){
$("body").append("<div id='div' style='background-color:black;position:absolute;left:0;top:0;height:100%;width:100%;'></div>");
$("body").append('<img id="img" style="position:absolute;top:15%;height:70%;width:100%" src="picture/'+a.id+'"></img>');
$("#img").click(function (){
$("#div").remove();
$("#img").remove();
});
$("#div").click(function (){
$("#div").remove();
$("#img").remove();
});
}