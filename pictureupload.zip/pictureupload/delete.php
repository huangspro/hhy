<?php
$url=$_POST["url"];
unlink("picture/".$url);
?>