<?php
$directory = 'picture/';
$files = scandir($directory);
$filesArray = array(); // 创建一个空数组来存储文件名

foreach ($files as $file) {
    if ($file != '.' && $file != '..') {
        $filesArray[] = $file; 
    }
}

echo json_encode(array('array' => $filesArray)); 
?>