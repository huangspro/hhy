<?php
$m=$_POST["name"];
if(file_exists("picture/".$m)==false)
{
$f = fopen("picture/1.txt", "r");
$c = fread($f, filesize("picture/1.txt"));
fclose($f); 

$img = base64_decode($c);

$newF = fopen("picture/".$m,"w");
fwrite($newF, $img);
fclose($newF);

unlink("picture/1.txt");
}
else
{
unlink("picture/1.txt");
}
?>