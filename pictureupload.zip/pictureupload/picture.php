<?php
$p =$_POST["p"];
$m=$_POST["name"];
if($m!="")
{
if(strpos($m,"png")!==false)
    {
    $base64Data = str_replace('data:image/png;base64,', '', $p);
    file_put_contents("picture/1.txt", $base64Data,FILE_APPEND);
    echo "ok";
    }
if(strpos($m,"jpg")!==false)
    {
    $base64Data = str_replace('data:image/jpeg;base64,', '', $p);
    file_put_contents("picture/1.txt", $base64Data,FILE_APPEND);
    echo "ok";
    }

if(strpos($m,"webp")!==false)
    {
    $base64Data = str_replace('data:image/webp;base64,', '', $p);
    file_put_contents("picture/1.txt", $base64Data,FILE_APPEND);
    echo "ok";
    }
}


?>