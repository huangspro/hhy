<?php

$s=$_POST['s'];
$directory = 'userblog/';
$files = scandir($directory);    
$files = array_diff($files, array('.', '..'));  
foreach ($files as $file) {  
if(strpos($file,$s)){
echo json_encode(array('ss'=>$file));
break;
} 
}
?>