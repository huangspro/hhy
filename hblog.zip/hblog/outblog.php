<?php
$t=$_POST['title'];
$c=$_POST['content'];
$ac=$_POST["ac"];

$h1='<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" id="viewport" content="width=device-width, initial-scale=1"></head>';
$h2="</body></html>";
if($t!="" && $c!=""){
$f=fopen("userblog/".$ac.".txt","w");
fwrite($f,$h1."<h>".$ac." 的blog</h><br><h>".$t."</h><br>"."<p>".$c."</p>".$h2);
fclose($f);
rename("userblog/".$ac.".txt","userblog/".$ac."的blog__".$t.".html");
}
?>