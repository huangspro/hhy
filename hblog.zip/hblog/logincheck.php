<?php
include "other/function.php";

$u=$_POST['usersname'];
$p=$_POST['password'];
if(checkkeyin($u,"login.json")=="in")
{
    if(logincheck($u,$p,"login.json")==1)
    {
    echo json_encode(array('status'=>'ok'));
    }
    else
    {
    echo json_encode(array('status'=>'passwordwrong'));
    }
}
else
{
echo json_encode(array('status'=>'keynotin'));
}
?>