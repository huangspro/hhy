<?php
include "other/function.php";
$u=$_POST['usersname'];
$p=$_POST['password'];
if($u!="" && $p!=""){
if(checkkeyin($u,"login.json")=="in")
{
echo json_encode(array('status'=>'in'));
}
else
{
newjson($u,$p,"login.json");
echo json_encode(array('status'=>'ok'));
}
}
?>