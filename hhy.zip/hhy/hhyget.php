<?php
header('Content-Type: application/json');
$json = file_get_contents('php://input');
$data = json_decode($json, true);
//数据格式["port(监听口号)"=>(四位口号),"ip(1或2)"=>(1或2)]
if($data["ip"]=="1"){
echo json_encode(array('message' => file_get_contents("data/".$data["port"]."1.txt")));
file_put_contents("data/".$data["port"]."1.txt","");
}
if($data["ip"]=="2"){
echo json_encode(array('message' => file_get_contents("data/".$data["port"]."2.txt")));
file_put_contents("data/".$data["port"]."2.txt","");
}
?>