<?php
header('Content-Type: application/json');
$json = file_get_contents('php://input');
$data = json_decode($json, true);
//数据格式["port(监听口号)"=>(四位口号),"ip(1或2)"=>(1或2),data=>(字符串数据)]
if($data["ip"]=="1"){
file_put_contents("data/".$data["port"]."2.txt",$data["data"]);
}
if($data["ip"]=="2"){
file_put_contents("data/".$data["port"]."1.txt",$data["data"]);
}
?>