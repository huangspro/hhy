package com.volley.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;
import android.os.*;
import android.widget.*;
import android.view.*;

public class MainActivity extends Activity{
    private volleytool v;
    private EditText editText;
    private Button button;
    private TextView textView;
    private CountDownTimer countDownTimer;
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        editText = findViewById(R.id.editText);
        textView = findViewById(R.id.textView);
        button = findViewById(R.id.button);
 	    v=new volleytool(this);
        startpolling();
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String text = editText.getText().toString();
                v.sendpost("http://192.168.1.4:5000/hhysend.php", jsonhelp.m("port", "1000", "ip","2","data",text), new volleytool.ResponseCallback() {
                @Override public void onGetResponse(final String message) {};
                });
            }
        });

    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (countDownTimer != null) {
            countDownTimer.cancel(); // 防止内存泄漏
        }
    }
    
    private void startpolling() {
    countDownTimer = new CountDownTimer(Long.MAX_VALUE, 1000) { 
        @Override
        public void onTick(long millisUntilFinished) {
            v.sendpost("http://192.168.1.4:5000/hhyget.php", jsonhelp.m("port", "1000", "ip","2"), new volleytool.ResponseCallback() {@Override public void onGetResponse(final String message) {textView.setText(message);}});
        }
        @Override
        public void onFinish() {}
    }.start();
}
}