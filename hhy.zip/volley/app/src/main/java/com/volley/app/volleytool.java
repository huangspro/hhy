package com.volley.app;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;
public class volleytool {
    private Context context;
    
    public interface ResponseCallback {
        void onGetResponse(String message);
    }

    public volleytool(Context context) {
        this.context = context;
    }

    public void sendpost(String url, JSONObject json,final ResponseCallback callback) {
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
            Request.Method.POST,
            url,
            json,
            new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    try {
                        String message = response.getString("message");
                        if (callback != null) {
                            callback.onGetResponse(message);
                        }
                    } catch (JSONException e) {}
                }
            },
            new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {}
            }); Volley.newRequestQueue(context).add(jsonObjectRequest);
    }
}